package finalProject;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class MyConnection {
    public static Connection getConnection(){
        ExecutorService executor = Executors.newFixedThreadPool(2);
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        try {
            Connection conn = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://sql3.freemysqlhosting.net:3306/sql3457862", "sql3457862", "cHInupmAFQ");
                DatabaseMetaData metaData = conn.getMetaData();
                System.out.println(lock.isLocked());
                int max = metaData.getMaxConnections();
                System.out.println("Max concurrent connections: " + max);
                System.out.println("Database is connected !");
            } catch (Exception e) {
                System.out.print("Do not connect to DB - Error:" + e);
            }
            return conn;
        }finally {
            lock.unlock();
        }
    }

}