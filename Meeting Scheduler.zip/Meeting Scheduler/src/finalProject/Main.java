package finalProject;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantLock;
public class Main extends JFrame implements ActionListener,Runnable {

    private Container c;
    private JLabel title;
    private JLabel name;
    private JTextField tname;
    private JLabel mno;
    private JLabel table_name;
    private JTextField tmno;
    private JLabel select_prof;
    private JComboBox date;
    private JComboBox time;
    private JComboBox teacher;
    private JLabel select_date;
    private JComboBox month;
    private JLabel select_time;
    private JComboBox year;
    private JButton sub;
    private JButton sub_pre;
    private JButton back;
    private JTable table;
    private Date date1;
    private DefaultTableModel defaultTableModel;
    private int prof_name_count=0;
    private boolean date_and_time_check=false;
    private boolean day_check=false;
    private boolean student_id_check=false;
    private boolean student_id_length_check=false;
    private boolean student_double_id_check=false;
    private String prof_name;
    private int id_of_student;
    private LinkedList<String> index=new LinkedList<>();
    private String[] arr=new String[10];
    private Date real_date;
    private String permanent_student_name;

    private String prof[]
            = { "Argus Filch", "Filius Flitwick", "Gilderoy Lockhart", "Poppy Pomfrey", "Quirinus Quirrell",
            "Horace Slughorn","Sybill Trelawney","Pomona Sprout"};


    public static String[] removeTheElement(String[] arr, int index)
    {

        // If the array is empty
        // or the index is not in array range
        // return the original array
        if (arr == null || index < 0
                || index >= arr.length) {

            return arr;
        }

        // Create another array of size one less
        String[] anotherArray = new String[arr.length - 1];

        // Copy the elements except the index
        // from original array to the other array
        for (int i = 0, k = 0; i < arr.length; i++) {

            // if the index is
            // the removal element index
            if (i == index) {
                continue;
            }

            // if the index is not
            // the removal element index
            anotherArray[k++] = arr[i];
        }

        // return the resultant array
        return anotherArray;
    }

    private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
        return sDate;
    }


    // constructor to initialize the components with default values.

    public Main()throws IOException{


        String dates[]
                = { "1", "2", "3", "4", "5",
                "6", "7", "8", "9", "10",
                "11", "12", "13", "14", "15",
                "16", "17", "18", "19", "20",
                "21", "22", "23", "24", "25",
                "26", "27", "28", "29", "30",
                "31" };
        String months[]
                = { "01", "02", "03", "04",
                "05", "06", "07", "08",
                "09", "10", "11", "12" };
        String years[]
                = { "2021", "2022", "2023", "2024",
                "2025", "2026" };
        String time_arr[]={
                "9am","10am","11am","12pm","1pm"
        };

        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("abcd.png")));
        setLayout(new FlowLayout());



        setTitle("Meeting Scheduler");
        setBounds(300, 90, 900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        title = new JLabel("Meeting Scheduler");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(300, 30);
        title.setLocation(300, 30);
        c.add(title);




        name = new JLabel("Name");
        name.setFont(new Font("Arial", Font.PLAIN, 18));
        name.setSize(100, 20);
        name.setLocation(100, 100);
        c.add(name);

        tname = new JTextField();
        tname.setFont(new Font("Arial", Font.PLAIN, 15));
        tname.setSize(190, 20);
        tname.setLocation(250, 100);
        c.add(tname);

        mno = new JLabel("Student ID");
        mno.setFont(new Font("Arial", Font.PLAIN, 18));
        mno.setSize(100, 20);
        mno.setLocation(100, 150);
        c.add(mno);

        tmno = new JTextField();
        tmno.setFont(new Font("Arial", Font.PLAIN, 15));
        tmno.setSize(150, 20);
        tmno.setLocation(250, 150);
        c.add(tmno);

        select_prof = new JLabel("Select Professor");
        select_prof.setFont(new Font("Arial", Font.PLAIN, 18));
        select_prof.setSize(200, 20);
        select_prof.setLocation(100, 200);
        c.add(select_prof);

        teacher = new JComboBox(prof);
        teacher.setFont(new Font("Arial", Font.PLAIN, 12));
        teacher.setSize(150, 30);
        teacher.setLocation(250, 200);
        c.add(teacher);

        JDateChooser dateChooser = new JDateChooser();
        dateChooser.setBounds(20, 20, 200, 20);
        dateChooser.setLocation(250,250);
        c.add(dateChooser);


        select_date = new JLabel("Select Date");
        select_date.setFont(new Font("Arial", Font.PLAIN, 18));
        select_date.setSize(100, 20);
        select_date.setLocation(100, 250);
        c.add(select_date);

        sub_pre = new JButton("Next");
        sub_pre.setFont(new Font("Arial", Font.BOLD, 15));
        sub_pre.setSize(100, 20);
        sub_pre.setLocation(250, 330);
        sub_pre.addActionListener(this);
        c.add(sub_pre);


        sub_pre.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                date1 = convertUtilToSql(dateChooser.getDate());
                long millis = System.currentTimeMillis();
                java.sql.Date check_date = new java.sql.Date(millis);
            
                PreparedStatement ps1, ps2;
                ResultSet rs1, rs2;
                
                String str_prof = (String) teacher.getSelectedItem();
                String student_Name = tname.getText();
                String length_check = tmno.getText().toString().trim();
                int student_ID = Integer.parseInt(tmno.getText());
                student_id_length_check = true;
                System.out.println("student id length: " + length_check.length());
                if (length_check.length() == 5) {
                    System.out.println("ID length is: 5");
                    student_id_length_check = false;
                }
                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {
                        student_double_id_check = false;
                        String query2 = "SELECT `Name` FROM `Student` WHERE `ID`=?";
                        ps2 = MyConnection.getConnection().prepareStatement(query2);
                        ps2.setInt(1, student_ID);
                        rs2 = ps2.executeQuery();
                        while (rs2.next()) {
                            if (rs2.getString("Name").equals(student_Name) == false) {
                                System.out.println("Duplicate id is present");
                                student_double_id_check = true;
                            }
                        }
                        rs2.close();
                        ps2.close();
                        MyConnection.getConnection().close();
                    } finally {
                        lock.unlock();
                    }
                } catch (Exception exception1) {
                    JOptionPane.showMessageDialog(null, exception1.getMessage());
                }

                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {

                        String query1 = "SELECT * FROM `Teachers` WHERE `Name`=?";
                        ps1 = MyConnection.getConnection().prepareStatement(query1);
                        ps1.setString(1, str_prof);
                        rs1 = ps1.executeQuery();
                        while (rs1.next()) {
                            Date date = rs1.getDate("Date");
                            System.out.println(date + "  " + date1);
                            if (date1.toString().equals(date.toString())) {
                                System.out.println(date);
                                System.out.println(date.toLocalDate().getDayOfMonth());
                                System.out.println(date.toLocalDate().getMonthValue());
                                System.out.println(date.toLocalDate().getYear());
                                String time = rs1.getString("Time");
                                System.out.println(time_arr.length);
                                for (int i = 0; i < time_arr.length; i++) {
                                    System.out.println(time_arr[i] + "  " + time);
                                    if (time_arr[i].equals(time)) {
                                        index.add(time);
                                        System.out.println(i);
                                    }
                                }
                            }
                        }
                        System.out.println("size of index: " + index.size());
                  
                        arr = time_arr;
                        for (int i = 0; i < index.size(); i++) {
                            for (int j = 0; j < arr.length; j++) {
                                if (arr[j].equals(index.get(i)))
                                    arr = removeTheElement(arr, j);
                            }
                            for (String element : arr) {
                                System.out.print(" " + element + " ");
                            }
                        }
                        index.clear();

                
                        rs1.close();
                        ps1.close();
                        MyConnection.getConnection().close();
                    } finally {
                        lock.unlock();
                    }
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, exception.getMessage());
                }
                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {
                        student_id_check = false;
                        String query2 = "SELECT `Name` FROM `Teachers` WHERE `Name`=?  AND `Date`=? AND `Student_ID`=?";
                        ps2 = MyConnection.getConnection().prepareStatement(query2);
                        ps2.setString(1, str_prof);
                        ps2.setDate(2, date1);
                        ps2.setInt(3, student_ID);
                        rs2 = ps2.executeQuery();
                        if (rs2.next() == true) {
                            System.out.println("Double id is oresent");
                            student_id_check = true;
                        }
                        rs2.close();
                        ps2.close();
                        MyConnection.getConnection().close();
                    } finally {
                        lock.unlock();
                    }
                } catch (Exception exception1) {
                    JOptionPane.showMessageDialog(null, exception1.getMessage());
                }

                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {
                        prof_name_count = 0;
                        String query2 = "SELECT * FROM `Teachers` WHERE `Name`=? AND `Date`=?";
                        ps2 = MyConnection.getConnection().prepareStatement(query2);
                        ps2.setString(1, str_prof);
                        ps2.setDate(2, date1);
                        rs2 = ps2.executeQuery();
                        while (rs2.next()) {
                            prof_name_count++;
                        }
                        rs2.close();
                        ps2.close();
                        MyConnection.getConnection().close();
                    } finally {
                        lock.unlock();
                    }
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(null, exception.getMessage());
                }
                String s = (String) teacher.getSelectedItem();
                System.out.println();
                System.out.println(student_id_length_check);
                day_check = false;
                Calendar c = Calendar.getInstance();
                c.setTime(date1);
                int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
                if (dayOfWeek == 1 || dayOfWeek == 7) {
                    day_check = true;
                }
                if (prof_name_count >= 4) {
                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled. Professor already has 4 meetings booked on this date");
                } else {
                    if (student_double_id_check) {
                    JOptionPane.showMessageDialog(null, "Please enter correct Student ID.Student ID is unique and can only have one name associated with it");

                } else {
                    if (day_check) {
                        JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled on Weekends.");
                    } else {
                        if (student_id_check) {
                            JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled for duplicate ID.");
                        } else {
                            if (date1.compareTo(check_date) < 0) {
                                JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled for previous date.");
                            } else {
                                if (student_id_length_check)
                                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled. Kindly Enter 5 digit ID ");
                                else {
                                    dispose();
                                    try {
                                        new Main(s, student_ID, arr, date1, student_Name);
                                    } catch (IOException e1) {

                                        // TODO Auto-generated catch block
                                        System.out.println(e1.getMessage());
                                        e1.printStackTrace();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }
        });

        setVisible(true);

        ActionListener cbActionListener = new ActionListener() {//adding ActionListner to listen for change
            @Override
            public void actionPerformed(ActionEvent e) {

                String s = (String) teacher.getSelectedItem();//to get the selected item

                switch (s) {//check for a match
                    case "Argus Filch":
                        System.out.println(s);

                        break;
                    case "Filius Flitwick":
                        System.out.println(s);
                        break;
                    case "Gilderoy Lockhart":
                        System.out.println(s);

                        break;
                    case "Poppy Pomfrey":
                        System.out.println(s);
                        break;
                    case "Quirinus Quirrell":
                        System.out.println(s);
                        break;
                    case "Horace Slughorn":
                        System.out.println(s);

                        break;
                    case "Sybill Trelawney":
                        System.out.println(s);

                        break;
                    case "Pomona Sprout":
                        System.out.println(s);


                        break;

                    default:
                        System.out.println(s);
                        break;
                }
            }
        };
        teacher.addActionListener(cbActionListener);
    }
    public Main(String str,int id,String[] time_arr,Date temp_date,String name)throws IOException{


        real_date=temp_date;
        id_of_student=id;
        prof_name=str;
        permanent_student_name=name;

        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("abcd.png")));
        setLayout(new FlowLayout());


        setTitle("Meeting Scheduler");
        setBounds(300, 90, 900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        c = getContentPane();
        c.setLayout(null);

        table_name = new JLabel("Appointment List");
        table_name.setFont(new Font("Arial", Font.BOLD, 23));
        table_name.setSize(200, 40);
        table_name.setLocation(250, 50);
        c.add(table_name);



        defaultTableModel = new DefaultTableModel();
        table=new JTable(defaultTableModel);
        table.setFont(new Font("Arial",Font.PLAIN,12));
        table.setSize(600,300);
        table.setLocation(100,100);
        defaultTableModel.addColumn("Name");
        defaultTableModel.addColumn("Date");
        defaultTableModel.addColumn("Time");
        defaultTableModel.addColumn("Student ID");
        defaultTableModel.addColumn("Student Name");
        c.add(table);
        try {
            PreparedStatement ps,ps2;
            ResultSet rs,rs2;
            ReentrantLock lock = new ReentrantLock();
            lock.lock();
            try {
                defaultTableModel.addRow(new Object[]{"Name","Date" , "Time","Student ID","Student Name"});
                String query = "SELECT * FROM `Teachers`";
                String query2= "SELECT `Name` FROM `Student`";
                ps = MyConnection.getConnection().prepareStatement(query);
                rs = ps.executeQuery();
                ps2 = MyConnection.getConnection().prepareStatement(query2);
                rs2 = ps2.executeQuery();
                while (rs.next() == true&&rs2.next()==true) {
                    String prof_name_temp = rs.getString("Name");
                    Date date_temp = rs.getDate("Date");
                    String time_temp = rs.getString("Time");
                    int id_temp=rs.getInt("Student_ID");
                    String stud_name_temp=rs2.getString("Name");
                    defaultTableModel.addRow(new Object[]{prof_name_temp,date_temp , time_temp,id_temp,stud_name_temp});
                }
                rs.close();
                ps.close();
                MyConnection.getConnection().close();
            }finally {
                lock.unlock();
            }
        } catch (Exception exception1) {
            JOptionPane.showMessageDialog(null, exception1.getMessage());
        }
        select_time = new JLabel("Select Time");
        select_time.setFont(new Font("Arial", Font.PLAIN, 12));
        select_time.setSize(100, 20);
        select_time.setLocation(100, 450);
        c.add(select_time);

        time = new JComboBox(time_arr);
        time.setFont(new Font("Arial", Font.PLAIN, 12));
        time.setSize(150, 20);
        time.setLocation(200, 450);
        c.add(time);

        sub = new JButton("Submit");
        sub.setFont(new Font("Arial", Font.PLAIN, 12));
        sub.setSize(100, 20);
        sub.setLocation(150, 500);
        sub.addActionListener(this);
        c.add(sub);

        back = new JButton("Back");
        back.setFont(new Font("Arial", Font.PLAIN, 12));
        back.setSize(100, 20);
        back.setLocation(250, 500);
        back.addActionListener(this);
        c.add(back);

        back.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                dispose();
                try {
                    new Main();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    System.out.println(e1.getMessage());
                    e1.printStackTrace();
                }
            }
        });

        setVisible(true);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == sub) {
            PreparedStatement ps1, ps2, ps3, ps4;
            ResultSet rs2, rs3, rs4;
            String str_time = (String) time.getSelectedItem();

            try {
                ReentrantLock lock = new ReentrantLock();
                lock.lock();
                try {
                    date_and_time_check = false;
                    String query2 = "SELECT * FROM `Teachers` WHERE `Name`=? AND `Date`=? AND `Time`=?";
                    ps3 = MyConnection.getConnection().prepareStatement(query2);
                    ps3.setString(1, prof_name);
                    ps3.setDate(2, real_date);
                    ps3.setString(3, str_time);
                    rs3 = ps3.executeQuery();
                    if (rs3.next() == true) {
                        System.out.println(date1 + " " + str_time);
                        date_and_time_check = true;
                    }
                    rs3.close();
                    ps3.close();
                    MyConnection.getConnection().close();
                }finally {
                    lock.unlock();
                }
            } catch (Exception exception1) {
                JOptionPane.showMessageDialog(null, exception1.getMessage());
            }
            day_check=false;
            Calendar c = Calendar.getInstance();
            c.setTime(real_date);
            int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == 1 || dayOfWeek == 7) {
                day_check = true;
            }
            if (day_check || date_and_time_check || prof_name_count == 4 || student_id_check) {
                if(day_check)
                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled.It's Weekend");
                if(date_and_time_check)
                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled. This slot already booked");
                if(prof_name_count>=4)
                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled. This professor already has 4 slots booked");
                if(student_id_check)
                    JOptionPane.showMessageDialog(null, "Meeting can't be Scheduled. Student with the same ID already present");

            } else {
                String query = "INSERT INTO `Teachers`(`Name`, `Date`, `Time`,`Student_ID`) VALUES (?,?,?,?)";
                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {
                        ps1 = MyConnection.getConnection().prepareStatement(query);
                        ps1.setString(1, prof_name);
                        ps1.setDate(2, real_date);
                        ps1.setString(3, str_time);
                        ps1.setInt(4, id_of_student);
                        if (ps1.executeUpdate() > 0) {
                            JOptionPane.showMessageDialog(null, "Scheduled Successfully");
                        }
                        ps1.close();
                        MyConnection.getConnection().close();
                    }finally {
                        lock.unlock();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
                String query1 = "INSERT INTO `Student`(`ID`, `Name`) VALUES (?,?)";
                try {
                    ReentrantLock lock = new ReentrantLock();
                    lock.lock();
                    try {
                        ps2 = MyConnection.getConnection().prepareStatement(query1);
                        ps2.setInt(1, id_of_student);
                        ps2.setString(2, permanent_student_name);
                        if (ps2.executeUpdate() > 0) {
                            JOptionPane.showMessageDialog(null, "Data Input was successful");
                        }
                        ps2.close();
                        MyConnection.getConnection().close();
                    } finally {
                        lock.unlock();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
            dispose();
            try {
                new Main();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

        }

    }

  
    public static void main(String[] args) {

        int[] arr={1,2,3};
        long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
        System.out.println(date);
        Runnable r=()-> {
            System.out.println(Thread.activeCount());
            try {
                Main main = new Main();

            } catch (IOException e) {
                // TODO Auto-generated catch block
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
            MyConnection.getConnection();
        };
        Thread thread=new Thread(r);
        thread.start();



    }

    @Override
    public void run() {
        Thread.State state = Thread.currentThread().getState();
        System.out.println("Running thread name: "+ Thread.currentThread().getName());
        System.out.println("State of thread: " + state);
    }
}
